/* Create Database ... */
Create database Miniproject_01 ;

/* Use Database ... */
Use Miniproject_01 ;

/* Admin Table ... */
Create table Admin (Name varchar (30) , Password varchar (20) , Email varchar (30) , PhoneNo varchar (15) , Type varchar (10) , AdminId int , DateOfJoining varchar (15));

/* Customer Table ... */
Create table Customer (Name varchar (30) , Password varchar (20) , Email varchar (30) , PhoneNo varchar (15) , Type varchar (10) , Address varchar (100));

/* FoodMenu Table ... */
Create table FoodMenu (FoodId int , FoodName varchar (30) , FoodPrice decimal (6,2) , NoOfPlates int);

/* OrderList Table ... */
Create table OrderList (CustomerPhoneNo varchar (15) , FoodId int , date date , Price decimal(6,2));

/* Cart Table ... */
Create table Cart (CustomerPhoneNo varchar (15) , FoodId int , date date , Price decimal(6,2));

/* Inserting Food Items In The Menu : */
insert into FoodMenu values 
(2022 , 'Dal Fry' , 120.00 , 20 ) , 
(6733 , 'Dal Makhani' , 150.00 , 20 ) ,
(1453 , 'Dum Aloo' , 160.00 , 20 ) ,
(5574 , 'Mix Veg Curry' , 180.00 , 20 ) ,
(9321 , 'Masala Paneer' , 220.00 , 20 ) ,
(2077 , 'Palak Panner' , 220.00 , 20 ) ,
(1993 , 'Mutter Paneer' , 200.00 , 20 ) ,
(3990 , 'Paneer Makhanni' , 200.00 , 20 ) ,
(6567 , 'Paneer Bhurji' , 180.00 , 20 ) ,
(3388 , 'Paneer Kofta' , 230.00 , 20 ) ,
(1522 , 'Tandoori Paneer' , 250.00 , 20 ) ,
(2800 , 'Egg Curry' , 120.00 , 20 ) ,
(2445 , 'Butter Chicken' , 280.00 , 20 ) ,
(4770 , 'Chicken Curry' , 300.00 , 20 ) ,
(4012 , 'Chicken Tikka Masala' , 350.00 , 20 ) ,
(1007 , 'Tandoori Chicken' , 380.00 , 20 ) ,
(1599 , 'Tandori Roti' , 20.00 , 20 ) ,
(6299 , 'Butter Tandori Roti' , 25.00 , 20 ) ,
(7723 , 'Tawa Roti' , 15.00 , 20 ) ,
(8401 , 'Rumali Roti' , 25.00 , 20 ) ,
(4949 , 'Lacha Paratha' , 30.00 , 20 ) ,
(4211 , 'Aloo Paratha' , 40.00 , 20 ) ,
(5390 , 'Onion Paratha' , 35.00 , 20 ) ,
(6523 , 'Paneer Paratha' , 55.00 , 20 ) ,
(9099 , 'Boiled Rice' , 100.00 , 20 ) ,
(2001 , 'Zeera Rice' , 125.00 , 20 ) ,
(3065 , 'Paneer Fried Rice' , 165.00 , 20 ) ,
(4981 , 'Egg Biryani' , 180.00 , 20 ) ,
(5385 , 'Chicken Biryani' , 220.00 , 20 ) 
(4444 , 'Chilli Chicken' , 180.00 , 20 ) ;

/* Inserting Dummy Orders Into OrderList */
insert into OrderList values 
('8759338423' , 4981 ,'2022-12-31', 3020.00 ) ,
('9759338423' , 3065 ,'2022-12-15', 2200.00 ) ,
('7659338423' , 5385 ,'2022-12-11', 2910.00 ) ,
('7705338423' , 4444 ,'2022-11-21', 3200.00 ) ,
('8798838423' , 4444 ,'2022-12-21', 1020.00 ) ,
('6259338423' , 5385 ,'2022-11-10', 3000.00 ) ,
('7593398423' , 4444 ,'2022-11-01', 1010.00 ) ,
('8755348423' , 5385 ,'2022-10-31', 2820.00 ) ,
('6559338423' , 4012 ,'2022-10-25', 720.00 ) ,
('9979338423' , 4981 ,'2022-09-21', 4020.00 ) ;
