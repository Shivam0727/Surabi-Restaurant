package com.miniproject_1.main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import com.coding.challenge.logging.UserLog;
import com.miniproject_1.designPattern.DesignClass;

public class Main {
	// Main Method From Where Code Is Going To Start ...
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\t|*********************************| RESTAURANT BILLING SYSTEM |*********************************|");
		int input=0 ;
		try
		{
			do 
			{
				// Main Menu Which Has 3 Options i.e; Register , Login and Exit ...
				{
					System.out.println("\n\n\t\t|-------------------------------|  Main  Menu  |----------------------------------|");
					System.out.println("\n\t\tPlease Select Any One Of The Option Given Below : ");
					System.out.println("\n\t\t1- Register \t 2- Login \t 3- Exit");
					System.out.print("\n\t\tYour Choice : ");
					input = sc.nextInt();
					sc.nextLine();	
					DesignClass.getMenu(input);
				}
			}
			while(input!=3);
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			// Logging Message ...
			UserLog.writeLog("Exception Occured ...");
		}
		// Exit The Applications ...
		System.out.println("\n\t\tThankyou For Using Our Application !!!");
		System.out.println("\t\t\t See You Soon !!!");
		LocalDateTime date = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		String dateStr = "Log-In TimeStamp : "+date.format(dtf);
		System.out.println("\t\t"+dateStr);
		// Logging Message ...
		UserLog.writeLog("Thankyou For Using Our Application !!! See You Soon ...");

	}

}
