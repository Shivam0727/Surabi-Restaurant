package com.miniproject_1.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.coding.challenge.logging.UserLog;

public class JdbcConnection {
	public static Connection conn;
	private static JdbcConnection single_connection=null;  //object

	public JdbcConnection() 
	{
		try 
		{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/MiniProject_01","root","Shivam@07122000");
		}
		catch (SQLException e)
		{
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}

	public static JdbcConnection getConnection() throws SQLException
	{
		if(single_connection==null)   //you are not connected to the database
		{
			single_connection=new JdbcConnection();
		}
		return single_connection;
	}
}
