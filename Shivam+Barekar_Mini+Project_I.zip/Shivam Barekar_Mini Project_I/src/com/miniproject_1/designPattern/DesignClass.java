package com.miniproject_1.designPattern;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.coding.challenge.logging.UserLog;
import com.miniproject_1.DaoImpl.AdminDaoImpl;
import com.miniproject_1.DaoImpl.CustomerDaoImpl;
import com.miniproject_1.DaoImpl.UserDaoImpl;
import com.miniproject_1.exceptions.InputTypeMismatchException;

@FunctionalInterface
interface UserRegister 
{
	public abstract void Signup();
}

@FunctionalInterface
interface UserLogin 
{
	public abstract void Signin();
}

@FunctionalInterface
interface AddFood 
{
	public abstract void addFood();
}

@FunctionalInterface
interface DeleteFood 
{
	public abstract void deleteFood();
}

@FunctionalInterface
interface UpdateFood 
{
	public abstract void updateFood();
}

@FunctionalInterface
interface DisplayMenu 
{
	public abstract void displayMenu();
}

@FunctionalInterface
interface BillOfDay 
{
	public abstract void billOfDay();
}

@FunctionalInterface
interface SalesForMonth 
{
	public abstract void salesForMonth();
}

@FunctionalInterface
interface ViewMenu 
{
	public abstract void viewMenu();
}

@FunctionalInterface
interface Order 
{
	public abstract void order();
}

@FunctionalInterface
interface TotalBill 
{
	public abstract void totalBill();
}

@FunctionalInterface
interface ViewProfile 
{
	public abstract void viewProfile();
}

// Using Designing Pattern :
public class DesignClass {
	// Declaring Static References ...
	static Scanner sc = new Scanner(System.in);
	static UserDaoImpl uimpl = UserDaoImpl.getConnection();
	public static	AdminDaoImpl obj1 = new AdminDaoImpl();
	public static CustomerDaoImpl obj2 = new CustomerDaoImpl();
	public static void getMenu(int input) {	
		try
		{
			if(input==1)
			{
				UserRegister register = ()-> {	
					// Calling Register Method From UserDaoImpl Class ...
					uimpl.register();	
				};
				register.Signup();
			}
			else if(input==2)
			{		
				UserLogin  login = ()-> {						
					// Calling Login Method From UserDaoImpl Class ...
					uimpl.login();
				};
				login.Signin();
			}
			else if(input==3)
			{
				// Exit
			}
			else
			{
				throw new InputTypeMismatchException();
			}	
		}
		catch(InputTypeMismatchException itme)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}
	@SuppressWarnings("deprecation")
	public static void getAdminMenu(int choice) {
		try
		{
			switch(choice)
			{
			case 1:	
				// Admin Food Manipulation Menu ...
				System.out.println("\n\t\t|------------------------------| MANIPULATE MENU |--------------------------------|");
				System.out.println("\n\t1- Add Items In Menu   2- Delete Items From Menu   3- Update Items From Menu   4- Go To Admin Menu");
				System.out.print("\n\tEnter Choice : ");
				int option = sc.nextInt();
				switch(option)
				{
				case 1 : AddFood addFood =()-> {
					// Calling AddFoodInMenu Method From AdminDaoImpl ...
					obj1.addFoodInMenu();					
				};
				addFood.addFood();
				break;
				// Calling DeleteFoodFromMenu Method From AdminDaoImpl ...
				case 2 : DeleteFood deleteFood =()-> {
					obj1.deleteFoodFromMenu();					
				};
				deleteFood.deleteFood();
				break;
				case 3 : UpdateFood updateFood =()-> {
					// Calling UpdateMenu Method From AdminDaoImpl ...
					obj1.updateMenu();					
				};
				updateFood.updateFood();
				break;
				case 4 :
					break;
				default :
					throw new InputTypeMismatchException();
				}
				break;
			case 2: DisplayMenu displayMenu =()-> {
				// Calling DisplayMenu Method From AdminDaoImpl ...
				obj1.displayMenu();				
			};
			displayMenu.displayMenu();
			break;
			case 3: BillOfDay billOfDay =()-> {
				// Calling BillOfDay Method From AdminDaoImpl ...
				obj1.totalBillGeneratedToday();				
			};
			billOfDay.billOfDay();
			break;
			case 4: SalesForMonth sales =()-> {
				// Calling SalesForThisMethod Method From AdminDaoImpl ...
				obj1.salesForThisMonth();				
			};
			sales.salesForMonth();
			break;
			case 5:
				// Admin Logout Process ...
				UserDaoImpl.thread.stop();
				System.out.println("\n\t\tCongratulations !!! Thread Is Stopped ...");
				System.out.println("\n\t\tThread Name : "+UserDaoImpl.thread.getName());
				System.out.println("\n\t\tThread ID : "+UserDaoImpl.thread.getId());
				UserLog.writeLog("Thread Stopped Successfully !!!");
				LocalDateTime logoutdate = LocalDateTime.now();
				DateTimeFormatter logoutdtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
				String dateTime = "Log-Out TimeStamp : "+logoutdate.format(logoutdtf);
				System.out.println("\n\t\tCongratulations !!! Admin Log-Out Process Done Successfully ...");
				System.out.println("\t\t"+dateTime);
				UserLog.writeLog("Admin Log-Out Successfully !!!");
				break;
			default : throw new InputTypeMismatchException();
			}
		}
		catch(InputTypeMismatchException itme)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}

	@SuppressWarnings("deprecation")
	public static void getCustomerMenu(int choice) {
		try
		{
			switch(choice)
			{
			case 1: ViewMenu viewMenu =()-> {
				// Calling ViewMenu Method From CustomerDaoImpl ...
				obj2.viewMenu();				
			};
			viewMenu.viewMenu();
			break;
			case 2: Order order =()-> {
				// Calling OrderItem Method From CustomerDaoImpl ...
				obj2.orderItem();				
			};
			order.order();
			break;
			case 3: TotalBill totalBill = ()-> {
				// Calling ViewFinalBill Method From CustomerDaoImpl ...
				obj2.viewFinalBill();				
			};
			totalBill.totalBill();
			break;
			case 4: ViewProfile viewProfile = ()-> {
				// Calling ViewProfile Method From CustomerDaoImpl ...
				obj2.viewProfile();
			};
			viewProfile.viewProfile();
				break;
			case 5:
				// Customer Logout Process ...
				UserDaoImpl.thread.stop();
				System.out.println("\n\t\tCongratulations !!! Thread Is Stopped ...");
				System.out.println("\n\t\tThread Name : "+UserDaoImpl.thread.getName());
				System.out.println("\n\t\tThread ID : "+UserDaoImpl.thread.getId());
				UserLog.writeLog("Thread Stopped Successfully !!!");
				LocalDateTime logoutdate = LocalDateTime.now();
				DateTimeFormatter logoutdtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
				String dateTime = "Log-Out TimeStamp : "+logoutdate.format(logoutdtf);
				System.out.println("\n\t\tCongratulations !!! Customer Log-Out Process Done Successfully ...");
				System.out.println("\t\t"+dateTime);
				UserLog.writeLog("Customer Log-Out Successfully !!!");
				break;
			default : throw new InputTypeMismatchException();

			}
		}
		catch(InputTypeMismatchException itme)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}
}
