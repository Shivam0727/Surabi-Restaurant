package com.miniproject_1.testing;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import com.miniproject_1.connection.JdbcConnection;
import com.miniproject_1.designPattern.DesignClass;

public class MiniProjectTesting {
	

	JdbcConnection connection = new JdbcConnection();
	
	@Before
	public void AddFoodInMenu()
	{
		assertEquals(true, DesignClass.obj1.addFoodInMenu());
	}
	@Test
	public void DeletefoodFromMenu()
	{
		assertEquals(true, DesignClass.obj1.deleteFoodFromMenu());
	}
	@Test
	public void UpdateFoodFromMenu()
	{
		assertEquals(true, DesignClass.obj1.updateMenu());
	}
	@Test
	public void DisplayMenu()
	{
		assertEquals(true, DesignClass.obj1.displayMenu());
	}
	@Test
	public void TotalBillGeneratedToday()
	{
		assertEquals(true, DesignClass.obj1.totalBillGeneratedToday());
	}	
	@Test
	public void SalesForThisMonth()
	{
		assertEquals(true, DesignClass.obj1.salesForThisMonth());
	}
	@Test
	public void ViewMenu()
	{
		assertEquals(true, DesignClass.obj2.viewMenu());
	}
	@Test
	public void OrderItem()
	{
		assertEquals(true, DesignClass.obj2.orderItem());
	}
	@Test
	public void ViewFinalBill()
	{
		assertEquals(true, DesignClass.obj2.viewFinalBill());
	}
}
