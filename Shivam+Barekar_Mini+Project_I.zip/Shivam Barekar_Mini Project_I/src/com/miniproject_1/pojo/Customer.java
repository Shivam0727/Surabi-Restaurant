package com.miniproject_1.pojo;

public class Customer extends User {
	private String address ;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [address=" + address + ", getName()=" + getName() + ", getPassword()=" + getPassword()
		+ ", getEmail()=" + getEmail() + ", getPhoneNo()=" + getPhoneNo() + ", getType()=" + getType()
		+ "]";
	}

}
