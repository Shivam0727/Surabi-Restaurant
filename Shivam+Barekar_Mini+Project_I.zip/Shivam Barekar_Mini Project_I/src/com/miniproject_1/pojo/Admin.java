package com.miniproject_1.pojo;

public class Admin extends User {
	private int adminId ;
	private String DateOfJoining ;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getDateOfJoining() {
		return DateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		DateOfJoining = dateOfJoining;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", DateOfJoining=" + DateOfJoining + ", getName()=" + getName()
		+ ", getPassword()=" + getPassword() + ", getEmail()=" + getEmail() + ", getPhoneNo()=" + getPhoneNo()
		+ ", getType()=" + getType()  + "]";
	}


}
