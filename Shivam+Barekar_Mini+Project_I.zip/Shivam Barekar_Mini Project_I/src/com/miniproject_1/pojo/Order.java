package com.miniproject_1.pojo;

import java.util.Date;

public class Order {
	private String customerPhoneNo ;
	private int foodId ;
	private Date date ;
	private float price ;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getCustomerPhoneNo() {
		return customerPhoneNo;
	}
	public void setCustomerPhoneNo(String customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Orders [customerPhoneNo=" + customerPhoneNo + ", foodId=" + foodId + ", date=" + date + ", price="
				+ price + "]";
	}	
}
