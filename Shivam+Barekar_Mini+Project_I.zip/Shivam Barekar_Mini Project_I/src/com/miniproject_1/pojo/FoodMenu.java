package com.miniproject_1.pojo;

public class FoodMenu {
private int foodId ;
private String foodName ;
private float price ;
private int noOfPlatesAvailable ;
public int getFoodId() {
	return foodId;
}
public void setFoodId(int foodId) {
	this.foodId = foodId;
}
public String getFoodName() {
	return foodName;
}
public void setFoodName(String foodName) {
	this.foodName = foodName;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public int getNoOfPlatesAvailable() {
	return noOfPlatesAvailable;
}
public void setNoOfPlatesAvailable(int noOfPlatesAvailable) {
	this.noOfPlatesAvailable = noOfPlatesAvailable;
}
@Override
public String toString() {
	return "FoodMenu [foodId=" + foodId + ", foodName=" + foodName + ", price=" + price + ", noOfPlatesAvailable="
			+ noOfPlatesAvailable + "]";
}

}
