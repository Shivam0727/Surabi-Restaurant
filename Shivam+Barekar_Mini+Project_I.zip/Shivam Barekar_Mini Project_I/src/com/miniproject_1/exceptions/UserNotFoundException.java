package com.miniproject_1.exceptions;

public class UserNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString()
	{
		return "\n\t\tUserNotFoundException Is Generated ...";

	}

}
