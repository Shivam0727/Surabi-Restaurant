package com.miniproject_1.exceptions;

public class FoodItemNotFoundException extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString()
	{
		return "\n\t\tWrong Food-ID Taken ... FoodItemNotFoundException Is Generated ...";
		
	}

}
