package com.miniproject_1.exceptions;

public class InputTypeMismatchException extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString()
	{
		return "\n\t\tWrong Input Taken ... InputTypeMismatchException Is Generated ...";
		
	}

}
