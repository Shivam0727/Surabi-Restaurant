package com.miniproject_1.DaoImpl;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import com.coding.challenge.logging.UserLog;
import com.miniproject_1.Dao.CustomerDao;
import com.miniproject_1.exceptions.FoodItemNotFoundException;
import com.miniproject_1.exceptions.InputTypeMismatchException;

public class CustomerDaoImpl implements CustomerDao {

	// Creating and Declaring Static References ...
	static Scanner sc = new Scanner(System.in);
	static int UpdatedPlates ;
	static int foodId ;
	static ArrayList<Integer> foodIdList = new ArrayList<>() ;
	static ArrayList<Integer> updatedPlatesList = new ArrayList<>() ;

	@SuppressWarnings("static-access")
	public  boolean viewMenu() {
		boolean flag=false;
		try
		{
			int n=1;
			// Displaying Food Menu To Customer Which Present In FoodMenu Table ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select * from FoodMenu Order By FoodPrice Asc");
			ResultSet rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tFood-Item["+n+"] : \n\t\tFoodId : "+rs.getInt("FoodId")+"\n\t\tFood-Name : "+rs.getString("FoodName")+"\n\t\tFood-Price : "+rs.getFloat("FoodPrice")+"\n\t\tNo Of Plates Available : "+rs.getInt("NoOfPlates"));
				n++;
				flag = true ;
			}
			UserLog.writeLog("Food Menu Displayed Successfully ...");
		}
		catch(SQLException sqle)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean  orderItem() {
		boolean flag=false;
		try
		{
			int choice ;
			do
			{
				// Order Menu Displayed To Customer ...
				System.out.println("\n\t\t|---------------------------| ORDER FOODS FROM MENU |-------------------------------|");
				System.out.println("\n\t1- Add Dish Into Cart \t 2- Remove Dish From The Cart \t 3- Placed The Order \t 4- Go Back To Customer Menu ");
				System.out.print("\n\tEnter Choice : ");
				choice = sc.nextInt();
				sc.nextLine();

				switch(choice)
				{
				case 1:
					flag = false;
					System.out.print("\n\t\tEnter Food-Id : ");
					foodId = sc.nextInt();
					sc.nextLine();
					System.out.print("\n\t\tEnter Number Of Quantity You Want to Order : ");
					int quantity = sc.nextInt();
					sc.nextLine();
					// Checking Whether FoodId i.e; Food Item Exist In The Food Menu Or Not ...
					UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("select exists (select * from FoodMenu where FoodId = ? ) as exist");
					UserDaoImpl.pstmt.setInt(1, foodId);
					foodIdList.add(foodId);
					ResultSet rs1 = UserDaoImpl.pstmt.executeQuery();
					while(rs1.next())
					{
						// Food Item Exist In The Menu Then And Only Then It Will Go To If Condition ...
						if(rs1.getInt("exist")!=0)
						{
							UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("select FoodPrice , NoOfPlates from FoodMenu where FoodId = ?");
							UserDaoImpl.pstmt.setInt(1, foodId);
							ResultSet rs2 = UserDaoImpl.pstmt.executeQuery();
							long millis=System.currentTimeMillis();  
							// Storing Todays Date In date Variable ...
							Date date = new Date(millis);
							while(rs2.next())
							{
								// Storing Updated Plates After Ordering In UpdatedPlates Variable ...
								UpdatedPlates = rs2.getInt("NoOfPlates")-quantity;
								updatedPlatesList.add(UpdatedPlates);
								// Storing Updated Price After Ordering In price Variable ...
								float price = rs2.getFloat("FoodPrice")*quantity;
								// Checking Whether No OF Plates Order By Customer Is Available Or Not ...
								if(rs2.getInt("NoOfPlates")>=quantity)
								{				
									// Inserting The Customer Order In The Cart Table Which Is Temporary Till Customer Placed The Order ...
									UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("insert into Cart values (?,?,?,?)");
									UserDaoImpl.pstmt.setString(1, UserDaoImpl.PhoneNo);
									UserDaoImpl.pstmt.setInt(2, foodId);
									UserDaoImpl.pstmt.setDate(3, date);
									UserDaoImpl.pstmt.setFloat(4, price);
									int result = UserDaoImpl.pstmt.executeUpdate();
									// If Result Greater Than Zero Then Customer Food Item Added In The Cart Successfully ...
									if(result>0)
									{
										System.out.println("\n\tCongratulations !!! Your Order Is Added In The Cart ...");
										UserLog.writeLog("Congratulations !!! Your Order Is Added In The Cart Successfully ...");
										flag = true ;
									}
								}
								else
								{
									// Customer Ordered Food Item Quantity Is Not Available ...
									System.out.println("\n\t\tOops !!! Your Required Quantity Of Dish Is Not Available ...");
									UserLog.writeLog("Oops !!! Your Required Quantity Of Dish Is Not Available ...");
									flag = false ;
								}
							}
						}
						else
						{
							throw new FoodItemNotFoundException();
						}
					}
					break;
				case 2:
					flag=false;
					System.out.print("\n\t\tEnter Food-Id For Delete Food Item From Cart : ");
					int deleteFoodId = sc.nextInt();
					sc.nextLine();
					// Checking Whether Food Item Which Customer Wants To Delete is Exist In The Cart Or Not ...
					UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("select exists (select * from Cart where FoodId = ? ) as exist");
					UserDaoImpl.pstmt.setInt(1, deleteFoodId);
					ResultSet rs = UserDaoImpl.pstmt.executeQuery();
					while(rs.next())
					{
						// Food Item Exist In The Cart ...
						if(rs.getInt("exist")!=0)
						{
							// Deleting Food Item From The Cart ...
							UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Delete From Cart Where FoodId=?");
							UserDaoImpl.pstmt.setInt(1, deleteFoodId);	
							foodIdList.remove(Integer.valueOf(deleteFoodId));
							int result = UserDaoImpl.pstmt.executeUpdate();
							if(result>0)
							{
								System.out.println("\n\t\tCongratulations !!! Food Item Removed From The Cart ...");
								UserLog.writeLog("Congratulations !!! Food Item Removed From The Cart ...");
								flag = true ;
							}
						}
						else
						{
							throw new FoodItemNotFoundException();
						}
					}

					break;
				case 3:
					flag=false;
					Random rand = new Random();
					int x = rand.nextInt(9000)+1000;
					System.out.println("\n\t\tOTP : "+x);
					// Customer Needs To Enter Otp For Placing The Order ...
					System.out.print("\n\t\tEnter OTP For Comfirmation : ");
					int otp = sc.nextInt();
					sc.nextLine();
					if(otp==x)
					{
						// Otp Matches And Hence The Food Item From Cart Is Moved To OrderList Table i.e; Order Placed Successfully ...
						UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("insert into OrderList select *from Cart ");
						int result = UserDaoImpl.pstmt.executeUpdate();
						if(result>0)
						{
							// Query For Remove All The Food Item From Customer Cart ...
							UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Truncate table Cart");
							UserDaoImpl.pstmt.executeUpdate();
							for(int i=0;i<foodIdList.size();i++)
							{
								// Updating Food Menu Quantity After Customer Placed The Order ...
								UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Update FoodMenu Set NoOfPlates=? where FoodId=?");
								UserDaoImpl.pstmt.setInt(1, updatedPlatesList.get(i));
								UserDaoImpl.pstmt.setInt(2, foodIdList.get(i));
								result = UserDaoImpl.pstmt.executeUpdate();
							}
							if(result>0)
							{
								System.out.println("\n\t\tCongratulations !!! Your Order Placed Successfully ...");
								UserLog.writeLog("Congratulations !!! Your Order Placed Successfully ...");
								flag = true ;
							}
							else
							{
								throw new FoodItemNotFoundException();
							}
						}
						else
						{
							System.out.println("\n\t\tOops !!! Your Cart Is Empty ...");
							UserLog.writeLog("Oops !!! Your Cart Is Empty ...");
						}
					}
					break;
				case 4:
					break;
				default : throw new InputTypeMismatchException();
				}

			}
			while(choice!=4);

		} 
		catch (FoodItemNotFoundException fnfe) 
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+fnfe);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (InputTypeMismatchException itme) 
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e) 
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean viewFinalBill() {
		boolean flag=false;
		try
		{
			long millis=System.currentTimeMillis();  
			// Storing Todays Date in date Variable ...
			Date date = new Date(millis);
			// Getting All The Order which Customer Order Today ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select *From OrderList where CustomerPhoneNo=? And date=?");
			UserDaoImpl.pstmt.setString(1, UserDaoImpl.PhoneNo);
			UserDaoImpl.pstmt.setDate(2, date);
			ResultSet rs = UserDaoImpl.pstmt.executeQuery();
			int n =1;
			while(rs.next())
			{
				System.out.println("\n\t\tOrder Summary ["+n+"] :\n\t\tCustomer Phone Number : "+rs.getString("CustomerPhoneNo")+"\n\t\tFood-Id : "+rs.getInt("FoodId")+"\n\t\tTodays Date : "+rs.getDate("Date")+"\n\t\tBill : "+rs.getFloat("Price"));
				n++;
				flag = true ;
			}
			// Calculating The Total Amount Customer Needs To Pay For Todays Oder ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select Sum(Price) as bill From OrderList where CustomerPhoneNo=?");
			UserDaoImpl.pstmt.setString(1, UserDaoImpl.PhoneNo);
			rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tTotal Bill Generated : "+rs.getFloat("bill")+" Rupees Only /-");
				flag = true ;
			}
			UserLog.writeLog("Total Bill Generated Successfully ...");
		} 
		catch (SQLException sqle)
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e)
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public boolean viewProfile()
	{
		boolean flag = false ;
		try 
		{
			Random rand = new Random();
			int x = rand.nextInt(9000)+1000;
			System.out.println("\n\t\tOTP : "+x);
			// Customer Needs To Enter Otp For Displaying Profile ...
			System.out.print("\n\t\tEnter OTP For Comfirmation : ");
			int otp = sc.nextInt();
			sc.nextLine();
			if(otp==x)
			{
				UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("select *from customer where PhoneNo = ?");
				UserDaoImpl.pstmt.setString(1, UserDaoImpl.PhoneNo);
				ResultSet rs = UserDaoImpl.pstmt.executeQuery();
				while(rs.next())
				{
					System.out.println("\n\t\t--> My Profile :\n\n\t\tName : "+rs.getString("Name")+"\n\t\tPassword : "+rs.getString("Password")+"\n\t\tEmail-Id : "+rs.getString("Email")+"\n\t\tPhone Number : "+rs.getString("PhoneNo")+"\n\t\tType : "+rs.getString("Type")+"\n\t\tAddress : "+rs.getString("Address"));
					flag = true ;
				}
			}
			else
			{
				throw new InputTypeMismatchException();
			}

		}
		catch (InputTypeMismatchException itme)
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (SQLException sqle)
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e)
		{
			// Exception Occured ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

}
