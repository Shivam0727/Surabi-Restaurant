package com.miniproject_1.DaoImpl;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import com.coding.challenge.logging.UserLog;
import com.miniproject_1.Dao.AdminDao;
import com.miniproject_1.connection.JdbcConnection;
import com.miniproject_1.exceptions.FoodItemNotFoundException;

public class AdminDaoImpl implements AdminDao {
	// Creating And Declaring Static References ...
	static Scanner sc = new Scanner(System.in);
	static Random rand = new Random();
	private static AdminDaoImpl conn = new AdminDaoImpl();
	public static AdminDaoImpl getConnection()
	{
		return conn;
	}

	// Default Constructor ...
	public AdminDaoImpl() 
	{
		try 
		{
			UserDaoImpl.con=JdbcConnection.getConnection();
		}
		catch (SQLException e)
		{
			// Exeption Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}

	@SuppressWarnings("static-access")
	public boolean addFoodInMenu() 
	{
		boolean flag=false;
		System.out.println("\n\t\t|------------------------------| ADD FOODS IN MENU |-------------------------------|");
		int foodId = rand.nextInt(9000)+1000;
		System.out.print("\n\t\tEnter Food-Name : ");
		String foodName = sc.nextLine();
		System.out.print("\n\t\tEnter Food-Price : ");
		float foodPrice = sc.nextFloat();
		System.out.print("\n\t\tEnter No Of Plates Available : ");
		int noOfPlates = sc.nextInt();
		sc.nextLine();

		try 
		{
			// Inserting Food Items Into FoodMenu Table ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("insert into FoodMenu values (?,?,?,?)");
			UserDaoImpl.pstmt.setInt(1, foodId);
			UserDaoImpl.pstmt.setString(2, foodName);
			UserDaoImpl.pstmt.setFloat(3, foodPrice);
			UserDaoImpl.pstmt.setInt(4, noOfPlates);

			int result = UserDaoImpl.pstmt.executeUpdate();
			// If Result greater Than Zero Then Food Items Inserted Into Table Successfully ...
			if(result>0)
			{
				System.out.println("\n\t\tCongratulations !!! Food Item Add In The Menu Successfully ...");
				UserLog.writeLog("Congratulations !!! Food Item Added In Menu Successfully ...");
				flag = true ;
			}
			else
			{
				throw new InputMismatchException();
			}
		} 
		catch (SQLException sqle)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean deleteFoodFromMenu()
	{
		boolean flag=false;
		System.out.println("\n\t\t|-------------------------| DELETE FOODS FROM MENU |-------------------------------|");
		// Taking FoodId WHich Admin Want Delete From Menu ...
		System.out.print("\n\t\tEnter Food-Id Which You Want To Delete From Menu : ");
		int foodId = sc.nextInt();
		sc.nextLine();
		try 
		{
			// Query For Deleting Food Item From Menu Table ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Delete from FoodMenu where FoodId=?");
			UserDaoImpl.pstmt.setInt(1, foodId);
			int result = UserDaoImpl.pstmt.executeUpdate();
			// If result greater Than Zero Then Food Item Deleted From Table Successfully ...
			if(result>0)
			{
				System.out.println("\n\t\tCongratulations !!! Food Item Deleted From The Menu Successfully ...");
				UserLog.writeLog("Congratulations !!! Food Item Deleted From The Menu Successfully ...");
				flag = true ;
			}	
			else
			{
				throw new FoodItemNotFoundException();
			}
		} 
		catch (FoodItemNotFoundException fnfe)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+fnfe);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (SQLException sqle)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean updateMenu() 
	{
		boolean flag=false;
		System.out.println("\n\t\t|---------------------------| UPDATE FOODS IN MENU |-------------------------------|");
		// Taking foodId Which Admin Want To Update ...
		System.out.print("\n\t\tEnter Food-Id Which You Want To Update From Menu : ");
		int foodId = sc.nextInt();
		sc.nextLine();
		try 
		{
			// Checking whether That FoodId Or FOodItem Is Exist In Table Or Not ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("select exists (select * from FoodMenu where FoodId = ? ) as exist");
			UserDaoImpl.pstmt.setInt(1, foodId);
			ResultSet rs1 = UserDaoImpl.pstmt.executeQuery();
			while(rs1.next())
			{
				// If FoodId Exist In Table Then If Goes TO If Condition ...
				if(rs1.getInt("exist")!=0)
				{
					System.out.print("\n\t\tEnter Food-Name : ");
					String foodName = sc.nextLine();
					System.out.print("\n\t\tEnter Food-Price : ");
					float foodPrice = sc.nextFloat();
					System.out.print("\n\t\tEnter No Of Plates Available : ");
					int noOfPlates = sc.nextInt();
					sc.nextLine();
					// Updating Food Item From Menu Table Using Update Query ...
					UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Update FoodMenu Set FoodName=? , FoodPrice=? , NoOfPlates=? where FoodId=?");
					UserDaoImpl.pstmt.setString(1, foodName);
					UserDaoImpl.pstmt.setFloat(2, foodPrice);
					UserDaoImpl.pstmt.setInt(3, noOfPlates);
					UserDaoImpl.pstmt.setInt(4, foodId);
					int result = UserDaoImpl.pstmt.executeUpdate();
					// If Result Greater Than Zero Then We Can Conclude Than Menu Item Updated Successfully ...
					if(result>0)
					{
						System.out.println("\n\t\tCongratulations !!! Food Item Updated From The Menu Successfully ...");
						UserLog.writeLog("Congratulations !!! Food Item Updated From The Menu Successfully ...");
						flag = true ;
					}								
				}
				else
				{
					throw new FoodItemNotFoundException();
				}
			}
		} 
		catch (FoodItemNotFoundException fnfe)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+fnfe);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (SQLException sqle)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean displayMenu() 
	{
		boolean flag=false;
		try
		{
			int n=1;
			// Displaying All The food Menu List Which Present In FoodMenu Table ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select * from FoodMenu Order By FoodPrice Asc");
			ResultSet rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tFood-Item["+n+"] : \n\t\tFoodId : "+rs.getInt("FoodId")+"\n\t\tFood-Name : "+rs.getString("FoodName")+"\n\t\tFood-Price : "+rs.getFloat("FoodPrice")+"\n\t\tNo Of Plates Available : "+rs.getInt("NoOfPlates"));
				n++;
				flag = true ;
			}
			UserLog.writeLog("Food Menu Displayed Successfully ...");
		}
		catch(SQLException sqle)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean totalBillGeneratedToday() 
	{
		boolean flag=false;
		try
		{
			// Displaying The Bills Which Present In OrderList Table Which Having Todays Date ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select * from OrderList where date=?");
			long millis=System.currentTimeMillis();    
			Date date = new Date(millis);
			UserDaoImpl.pstmt.setDate(1, date);
			ResultSet rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tOrder Summary :\n\t\tCustomer Phone Number : "+rs.getString("CustomerPhoneNo")+"\n\t\tFood-Id : "+rs.getInt("FoodId")+"\n\t\tTodays Date : "+rs.getDate("Date")+"\n\t\tBill : "+rs.getFloat("Price"));
				flag = true ;
			}
			// Adding All The Bill Earnings And Display The Overall Earning For Today ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select Sum(Price) as bill From OrderList where date=?");
			UserDaoImpl.pstmt.setDate(1, date);
			rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tTodays Earning : "+rs.getFloat("bill")+" Rupees Only /-");
				flag = true ;
			}
			UserLog.writeLog("Total Bill Generated Today Is Displayed Successfully ...");

		} 
		catch (SQLException sqle) 
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+sqle);
			UserLog.writeLog("Exception Occured ...");
		}
		catch (Exception e) 
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

	@SuppressWarnings("static-access")
	public  boolean salesForThisMonth() 
	{
		boolean flag=false;
		try
		{
			LocalDate ld = LocalDate.now();
			Month m = ld.getMonth();
			int month = m.getValue();
			// Adding All The Bills Which Occured In Current  Month and Calculating total Monthly Earning ...
			UserDaoImpl.pstmt = UserDaoImpl.con.conn.prepareStatement("Select Sum(price) as Earning from OrderList where MONTH(date)=?");
			UserDaoImpl.pstmt.setInt(1, month);
			ResultSet rs = UserDaoImpl.pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("\n\t\tTotal Monthly Earning : "+rs.getFloat("Earning")+" Rs /-");
				flag=true;
			}
			UserLog.writeLog("Total Bill Generated Today Is Displayed Successfully ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		return flag ;
	}

}
