package com.miniproject_1.DaoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
import com.coding.challenge.logging.UserLog;
import com.miniproject_1.Dao.UserDao;
import com.miniproject_1.connection.JdbcConnection;
import com.miniproject_1.designPattern.DesignClass;
import com.miniproject_1.exceptions.InputTypeMismatchException;
import com.miniproject_1.exceptions.UserNotFoundException;
import com.miniproject_1.pojo.Admin;
import com.miniproject_1.pojo.Customer;

public class UserDaoImpl extends Thread implements UserDao {
	// Create And Declaring Static References ...
	Scanner sc = new Scanner(System.in);
	public static UserDaoImpl thread ;
	static PreparedStatement pstmt;
	static String PhoneNo ;
	static JdbcConnection con;
	public static Customer customer ;
	private static UserDaoImpl conn = new UserDaoImpl();

	public static UserDaoImpl getConnection() {
		return conn;
	}

	// Default Constructor ...
	public UserDaoImpl() 
	{
		try 
		{
			// Creating Connection ...
			con=JdbcConnection.getConnection();
		}
		catch (SQLException e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
		}
	}

	// Parameterised Constructor ...
	public UserDaoImpl(int n)
	{

	}

	// Overriding Run Method Which Gives New Thread Details Whenever Admin or Customer Login ...
	public void run()
	{
		System.out.println("\n\t\tCongratulations !!! Thread Is Created ...");
		System.out.println("\n\t\tThread Name : "+Thread.currentThread().getName());
		System.out.println("\n\t\tThread ID : "+Thread.currentThread().getId());
		UserLog.writeLog("Thread Running Successfully !!!");
	}

	// Registration Process For User ...
	@SuppressWarnings("static-access")
	public void register() {
		try
		{
			System.out.println("\n\t\t|------------------------------| REGISTRATION PROCESS |------------------------------|");
			System.out.println("\n\t\tSelect User Type :");
			System.out.println("\n\t\t1- Register As Admin \t 2- Register As Customer");
			System.out.print("\n\t\tEnter Choice : ");
			int choice = sc.nextInt();
			sc.nextLine();
			Random rand = new Random();
			int upperbound = 200000 ;
			String name ;
			String email ;
			String password ;
			String doj ;
			String phoneNo ;
			boolean isValidUsername ;
			boolean isValidEmail ;
			boolean isValidPassword ;
			boolean isValidDate ;
			boolean isValidPhoneNo ;

			switch(choice)
			{
			case 1:
				Admin admin = new Admin();
				System.out.println("\n\t\t--> Please Enter Admin Details : ");
				admin.setAdminId(rand.nextInt(upperbound)+100000);
				System.out.print("\n\t\tEnter Name : ");
				name = sc.nextLine();
				// Checking Whether Name Is Valid Or Not ...
				isValidUsername = Pattern.matches("^[\\p{L} .'-]+$", name);
				if(isValidUsername)
				{
					admin.setName(name);			
				}
				else
				{
					System.out.println("\n\t\tEnter Valid User-Name ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Email : ");
				email = sc.nextLine();
				// Checking Whether Email Is Valid Or Not ...
				isValidEmail = Pattern.matches("([^A-Z].+)@(.+)", email);
				if(isValidEmail)
				{
					admin.setEmail(email);		
				}
				else
				{
					System.out.println("\n\t\tEnter Valid Email-Id ...");
					throw new InputTypeMismatchException();
				}
				System.out.println("\n\t\tPassword Is In The Given Format Only Acceptable : "
						+ "\n\n\t\t-At Least 8 Character , Max of 20 Characters"
						+ "\n\t\t-At Least One Upper-Case"
						+ "\n\t\t-At Least One Lower-Case"
						+ "\n\t\t-At Least One Number"
						+ "\n\t\t-At Least One Symbol @#$%=:?");

				System.out.print("\n\t\tEnter Password : ");
				password = sc.nextLine();
				isValidPassword = Pattern.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\\W]).{6,20})", password);
				// Checking Whether Password Is Valid Or Not ...
				if(isValidPassword)
				{
					admin.setPassword(password);

				}
				else
				{
					System.out.println("\n\t\tEnter Valid Password ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Phone Number : +91-");
				phoneNo = sc.nextLine();
				isValidPhoneNo = Pattern.matches("^\\d{10}$", phoneNo);
				// Checking Whether Phone No Is Valid Or Not ...
				if(isValidPhoneNo)
				{
					admin.setPhoneNo(phoneNo);					
				}
				else
				{
					System.out.println("\n\t\tEnter Valid Phone No. ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Date Of Joining In (YYYY-MM-DD) : ");
				doj = sc.nextLine();
				isValidDate = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$", doj);
				// Checking Whether Date Is Valid Or Not ...
				if(isValidDate)
				{
					admin.setDateOfJoining(doj);					
				}
				else
				{
					System.out.println("\n\t\tEnter Valid Date ...");
					throw new InputTypeMismatchException();
				}
				admin.setType("Admin");
				try
				{
					// Inserting Admin Details In Admin Table ...
					pstmt = con.conn.prepareStatement("insert into Admin values (?,?,?,?,?,?,?)");
					pstmt.setString(1, admin.getName());
					pstmt.setString(2, admin.getPassword());
					pstmt.setString(3, admin.getEmail());
					pstmt.setString(4, admin.getPhoneNo());
					pstmt.setString(5, admin.getType());
					pstmt.setInt(6, admin.getAdminId());
					pstmt.setString(7, admin.getDateOfJoining());
					int result=pstmt.executeUpdate();
					// If Result is greater than 0 Then We Can Conclude That Admin Details Insert Into Table Successfully ...
					if(result>0)
					{
						LocalDateTime date = LocalDateTime.now();
						DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
						String dateStr = "Registration TimeStamp : "+date.format(dtf);
						System.out.println("\n\t\tCongratulation !!! Admin Registration Successfully !!!");
						System.out.println("\t\t"+dateStr);
						UserLog.writeLog("Congratulations !!! Admin Registration Successfully ...");
					}

				}
				catch(Exception e)
				{
					// Exception Handler ...
					System.out.println("\n\t\tSorry Exception Occurs !!!");
					System.out.println("\n\t\tException Type : "+e);
					UserLog.writeLog("Exception Occured ...");
				}

				break;
			case 2:
				customer = new Customer();
				System.out.println("\n\t\t--> Please Enter Customer Details : ");
				System.out.print("\n\t\tEnter Name : ");
				name = sc.nextLine();
				// Checking Whether Name Is Valid Or Not ...
				isValidUsername = Pattern.matches("^[\\p{L} .'-]+$", name);
				if(isValidUsername)
				{
					customer.setName(name);			
				}
				else
				{
					System.out.println("\n\t\tEnter Valid User-Name ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Email : ");
				email = sc.nextLine();
				// Checking Whether Email Is Valid Or Not ...
				isValidEmail = Pattern.matches("([^A-Z].+)@(.+)", email);
				if(isValidEmail)
				{
					customer.setEmail(email);		
				}
				else
				{
					System.out.println("\n\t\tEnter Valid Email-Id ...");
					throw new InputTypeMismatchException();
				}
				System.out.println("\n\t\tPassword Is In The Given Format Only Acceptable : "
						+ "\n\n\t\t-At Least 8 Character , Max of 20 Characters"
						+ "\n\t\t-At Least One Upper-Case"
						+ "\n\t\t-At Least One Lower-Case"
						+ "\n\t\t-At Least One Number"
						+ "\n\t\t-At Least One Symbol @#$%=:?");

				System.out.print("\n\t\tEnter Password : ");
				password = sc.nextLine();
				// Checking Whether Password Is Valid Or Not ...
				isValidPassword = Pattern.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\\W]).{6,20})", password);
				if(isValidPassword)
				{
					customer.setPassword(password);

				}
				else
				{
					System.out.println("\n\t\tEnter Valid Password ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Phone Number : +91-");
				phoneNo = sc.nextLine();
				isValidPhoneNo = Pattern.matches("^\\d{10}$", phoneNo);
				// Checking Whether Phone No Is Valid Or Not ...
				if(isValidPhoneNo)
				{
					customer.setPhoneNo(phoneNo);					
				}
				else
				{
					System.out.println("\n\t\tEnter Valid Phone No. ...");
					throw new InputTypeMismatchException();
				}
				System.out.print("\n\t\tEnter Address : ");
				customer.setAddress(sc.nextLine());	
				customer.setType("Customer");
				try
				{
					// Inserting Customer Details Into Customer Table ...
					pstmt = con.conn.prepareStatement("insert into Customer values (?,?,?,?,?,?)");
					pstmt.setString(1, customer.getName());
					pstmt.setString(2, customer.getPassword());
					pstmt.setString(3, customer.getEmail());
					pstmt.setString(4, customer.getPhoneNo());
					pstmt.setString(5, customer.getType());
					pstmt.setString(6, customer.getAddress());
					int result=pstmt.executeUpdate();
					// If result greater Than 0 Then Customer Details Inserted Into Customer Table Successfully ...
					if(result==1)
					{
						LocalDateTime date = LocalDateTime.now();
						DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
						String dateStr = "Registration TimeStamp : "+date.format(dtf);
						System.out.println("\n\t\tCongratulation !!! Customer Registration Successfully !!!");
						System.out.println("\t\t"+dateStr);
						UserLog.writeLog("Congratulations !!! Customer Registration Successfully ...");
					}
				}
				catch(Exception e)
				{
					// Exception Handler ...
					System.out.println("\n\t\tSorry Exception Occurs !!!");
					System.out.println("\n\t\tException Type : "+e);
					UserLog.writeLog("Exception Occured ...");
				}
				break;
			default:
				throw new InputTypeMismatchException();

			}
		}
		catch(InputTypeMismatchException itme)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+itme);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}

	}
	@SuppressWarnings("static-access")
	public void login() {
		try
		{
			System.out.println("\n\t\t|------------------------------| LOGIN PROCESS |----------------------------------|");
			System.out.println("\n\t\tSelect User Type :");
			System.out.println("\n\t\t1- Login As Admin \t 2- Login As Customer");
			System.out.print("\n\t\tEnter Choice : ");
			int choice = sc.nextInt();
			sc.nextLine();
			switch(choice)
			{
			case 1:
				try
				{
					System.out.println("\n\t\tEnter Admin Login Details : ");
					System.out.print("\n\t\tEnter Email : ");
					String email = sc.nextLine();
					System.out.print("\n\t\tEnter Password : ");
					String password = sc.nextLine();
					// Checking Whether Given Details Match Any Of The record From Admin Table ...
					pstmt = con.conn.prepareStatement("select exists(select * From Admin where Email=? and Password=?) as exist");
					pstmt.setString(1,email);
					pstmt.setString(2,password);
					ResultSet result = pstmt.executeQuery();
					while(result.next())
					{
						// Execute When Details Matches From The Admin Table ...
						if(result.getInt("exist")==1)
						{	
							LocalDateTime date = LocalDateTime.now();
							DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
							String dateStr = "Log-In TimeStamp : "+date.format(dtf);
							System.out.println("\n\t\tCongratulations !!! Admin Login Successfully ...");
							System.out.println("\t\t"+dateStr);
							// Logging Messege Will Display ...
							UserLog.writeLog("Congratulations !!! Admin Login Successfully ...");
							thread = new UserDaoImpl(1);
							thread.start();
							// Calling Run Method ...
							try 
							{
								thread.join();
							} 
							catch (Exception e)
							{
								// Exception Handler ...
								System.out.println("\n\t\tException Type : "+e);
								UserLog.writeLog("Exception Occurs ...");
							}
							do
							{
								// Admin Menu Which Is Displayed To Only Admin ...
								System.out.println("\n\t\t|---------------------------------| ADMIN MENU |----------------------------------|");
								System.out.println("\n\t1- Manipulate Menu   2- Display Menu   3- Total Bill Generated Today   4- Total Sales For This Month   5- Log-Out");
								System.out.print("\n\tYour Choice : ");
								choice = sc.nextInt();
								sc.nextLine();
								DesignClass.getAdminMenu(choice);
							}
							while(choice!=5);

						}
						else
						{
							throw new UserNotFoundException();
						}					
					}
				}
				catch(UserNotFoundException e)
				{
					// Exception Handler ...
					System.out.println("\n\t\tSorry Exception Occurs !!!");
					System.out.println("\n\t\tException Type : "+e);
					UserLog.writeLog("Exception Occured ...");
				}
				break;
			case 2: 
				try
				{
					System.out.println("\n\t\tEnter Customer Login Details : ");
					System.out.print("\n\t\tEnter Email : ");
					String email = sc.nextLine();
					System.out.print("\n\t\tEnter Password : ");
					String password = sc.nextLine();

					// Checking Whether Given Details Match Any Of The record From Customer Table ...
					pstmt = con.conn.prepareStatement("select exists (select * From Customer where Email=? and Password=?) as exist");
					pstmt.setString(1,email);
					pstmt.setString(2,password);
					ResultSet result = pstmt.executeQuery();
					while(result.next())
					{
						// Executes Only When Given Details MAtches Any One Of Records From Customer Table ...
						if(result.getInt("exist")==1)
						{
							LocalDateTime date = LocalDateTime.now();
							DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
							String dateStr = "Log-In TimeStamp : "+date.format(dtf);
							System.out.println("\n\t\tCongratulations !!! Customer Login Successfully ...");
							System.out.println("\t\t"+dateStr);
							// Logging Messege Will Display ...
							UserLog.writeLog("Congratulations !!! Customer Login Successfully ...");
							thread = new UserDaoImpl(1);
							thread.start();
							// Calling Run Method ...
							try 
							{
								thread.join();
							} 
							catch (Exception e)
							{
								// Exception Handler ...
								System.out.println("\n\t\tException Type : "+e);
								UserLog.writeLog("Exception Occurs ...");
							}

							pstmt = con.conn.prepareStatement("select PhoneNo from Customer where Email=? And Password=?");
							pstmt.setString(1, email);
							pstmt.setString(2, password);
							ResultSet rs = pstmt.executeQuery();
							while(rs.next())
							{
								// Storing Customer Phone Number In PhoneNo Variable ...
								PhoneNo = rs.getString("PhoneNo");
							}
							do
							{
								// Customer Menu ...
								System.out.println("\n\t\t|------------------------------| CUSTOMER MENU |----------------------------------|");
								System.out.println("\n\t1- View Menu   2- Order Item   3- View Final Bill Generated   4- View Profile   5- Log-Out");
								System.out.print("\n\tYour Choice : ");
								choice = sc.nextInt();
								sc.nextLine();
								DesignClass.getCustomerMenu(choice);
							}
							while(choice!=5);
						}
						else
						{
							throw new UserNotFoundException();
						}						
					}
				}
				catch(UserNotFoundException e)
				{ 
					// Exception Handler ...
					System.out.println("\n\t\tSorry Exception Occurs !!!");
					System.out.println("\n\t\tException Type : "+e);
					UserLog.writeLog("Exception Occured ...");
				}
				break;
			default : throw new InputTypeMismatchException();
			}
		}
		catch(InputTypeMismatchException e)
		{
			// Exception Handler ...
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
		catch(Exception e)
		{
			// Exception Handler ...
			e.printStackTrace();
			System.out.println("\n\t\tSorry Exception Occurs !!!");
			System.out.println("\n\t\tException Type : "+e);
			UserLog.writeLog("Exception Occured ...");
		}
	}
}
