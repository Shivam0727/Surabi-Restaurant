package com.miniproject_1.Dao;

public interface CustomerDao {
public boolean viewMenu();
public boolean orderItem();
public boolean viewFinalBill();
public boolean viewProfile();
}
