package com.miniproject_1.Dao;

public interface AdminDao {
public boolean addFoodInMenu();
public boolean deleteFoodFromMenu();
public boolean updateMenu();
public boolean displayMenu();
public boolean totalBillGeneratedToday();
public boolean salesForThisMonth();
}
