package com.miniproject_1.Dao;

public  interface UserDao {
	// Login Abstract Method whose implementation is written in UserDaoImpl
		public abstract void login();
		// Register Abstract Method whose implementation is written in UserDaoImpl
		public abstract void register();
}
