package com.coding.challenge.logging;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class UserLog {
	
	public static void writeLog(String logMsg)
	{
		try 
		{
			// Creating Logging :
			Logger logger=Logger.getLogger("Magic Of Books");
			FileHandler fileHandler = new FileHandler("C:\\Users\\shivamraju.barekar\\eclipse-workspace\\Shivam Barekar_Week_2_graded project\\src\\UserLog.txt");
			logger.addHandler(fileHandler);
			// Adding Local-Date-Time Explicitly In Log-Message :
			LocalDateTime dateTime = LocalDateTime.now();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
			String dateStr = "TimeStamp : "+dateTime.format(dtf);
			String result = dateStr.concat(" "+logMsg+"\n");
			SimpleFormatter sm = new SimpleFormatter();
			fileHandler.setFormatter(sm);
			logger.info(result);

		} 
		catch (Exception e)
		{
			System.out.println("\n\tException Type : "+e);
		}
	}
}

