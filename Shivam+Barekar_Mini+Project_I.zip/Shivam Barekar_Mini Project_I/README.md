# MINI PROJECT - I
## Problem Statement
Surabi is a chain of restaurants. Till this time there billing system was manual but due to COVID 19 
they wanted to have a Billing System to provide better service to their customers.
### Users Stories :
1. As a user I should be able to log in and log out and register in the application.
2. As a user I should be able to see all the items available along with the price.
3. As a user I should be able to select the item I want to order.
4. As a user I should be able to order n number of plates per item,
5. As a user I should be able to order more than one item.
6. As a user I should be able to see my final bill on the screen.

### Admin Stories : 
1. As an admin I should be able to login and logout in the application
2. As an admin I should be able to see all the bills getting generated today.
3. As an admin I should be able to see the total sale from this month.
4. As an admin I should be able to perform CRUD on menu and menu items.

### Features : 
- It Handles All The Negative Conditions In A Good Manner Using Exception Handling .
- It Checks For All The Functionality Of Methods Which Is Written In The Project Using J-Unit Testing .
- It Shows The Logging Message Whenever The Function Runs Properly .
- Date-Time API Is Used In Good Manner To Display The Current Date-Time .
- Regular Expression Is Used To Validate The User Details In Proper Manner .
- Little Bit Amount Of Designing Pattern Is Used For Reduces The Main Class Logic .
- JDBC is User To Store The Things In Database Permanently .
- Proper Uses Of Classes And Interface Is Done Along With POJO Classes .
- Proper Use Of Lambda Expression Is Done During Calling The Method .
- User Friendly Project .

### Flow Of Execution :

#####1- REGISTRATION AND LOGIN PROCESS :
User Interface - It Show 3 Options To User :

	1- Register 	 2- Login  	3- Exit
	
##### - REGISTRATION PROCESS : 	
User Can Choose Any One Of Them . If User Select Option-3 i.e; Exit then User Can Successfully Closed The Application And The Compilation Goes To End .
If User Select Option-1 Then It Shows 2 Option :

	1- Register As Admin	 2- Register As Customer

User Can Select Any One Of Them . If User Select Option-1 i.e; Register As Admin , Then User Needs To Enter Proper Details Accordingly . If User Select Option-2 i.e; Register As Customer , Then Also User Needs To Enter Proper Fields As Mentioned There .

	Admin Details Required :					Customer Details Required :
	    				
	1- Name								1- Name
	2- Password 							2- Password
	3- Email							3- Email
	4- Phone Number							4- Phone Number
	5- Type (Autofilled As Admin)					5- Type (Autofilled As Customer)		
	6- Admin-Id (Randomly Generated)				6- Address 
	7- Date Of Joining 

-> Note : User Needs To Enter Proper Validate Details As Regular Expression Is Used If Wrong Type Enter Which Is Not Exists Then It Thorws Exception .

- Example For User To Enter Proper Details : 
	
	Admin Details :								Customer Details : 
	
	1- Name : Shivam Barekar						1- Name : Shivam Barekar
	2- Password : Shivam@07							2- Password : Shivam@07
	3- Email : shivambarekar07@gmail.com					3- Email : shivambarekar07@gmail.com	 
	4- Phone No. : 7038229942						4- Phone No. : 7038229942
	5- Type : Admin (Autofilled)						5- Type : Customer (Autofilled)
	6- Admin-Id : (Auto-Generated)						6- Address : Kuchana Complex
	7- Date Of Joining : 2022-11-15

###### - LOGIN PROCESS : 
Now If User Select Option-2 Then It Shows 2-Options :

	1- Login As Admin  	2- Login As Customer 
	
Let If User Select Option-1 i.e; Login As Admin Then User Need To Enter Proper Details As Per Mentioned . If Details Matches Then User Login Successfully As Admin . If User Select Option-2 i.e; Login As Customer Then User Need To Enter Proper Details Which Are Given During Registration And If Details Matches Then User Login Successfully As Customer .

	Admin Login Details Reqired :				Customer Login Details Required :
	
	1- Email 							1- Email	
	2- Password							2- Password								

Whenever Login Successfully By Admin Or Customer Then A New Thread Is Created .

-> Note : If User Enter Wrong Details During Login Then It Throws User Not Found Exceptions .

######2- ADMIN MENU :

After Successfully Login by Admin , The Admin Menu Will Display :

	|---------------------------------| ADMIN MENU |----------------------------------|

	1- Manipulate Menu   2- Display Menu   3- Total Bill Generated Today   4- Total Sales For This Month   5- Log-Out

1- If Admin Select Option-1 , Then Manipulation Menu Will Display :

	|------------------------------| MANIPULATE MENU |--------------------------------|

	1- Add Items In Menu   2- Delete Items From Menu   3- Update Items From Menu   4- Go To Admin Menu

- Now If Admin Want To Add New Items Into Menu , Then Admin Needs To Select Option-1 . Add tems Into Menu Ask For 3 Things :

	1- Enter Food-Name 
	2- Enter Food-Price 
	3- Enter No Of Plates Available 
	
Note : Food-Id Is Automatically Generated .

- Now If Admin Want To Delete Some Item Then Admin Needs To Select Option-2 . When Admin Select Option-2 Then Admin Need To Enter Food-Id Which Admin Want To Delete . If That Food-Id Exist In The Menu Then It Will Deleted Successfully But If Food-Id Doesnt Matches Then It Will Throws Exception i.e; Food Item Not Found Exception .
- If Admin Select Option-3 Then Admin Needs To Enter Food-Id , If Food-Id Matches Then And Only Then Admin Can Update Food In Menu .
- At Last If Admin Select Option-4 Then It Redirect To Admin Menu .
This Is All About Manipulate Menu .

2- Now If Admin Wants To View Food-Menu Then Admin Needs To Select Option-2 , Then Full Menu Will Display To It .

3- If Admin Wants To View Total Bills Generated Today Then Admin Needs To Enter Option-3 .

4- If Admin Wants To View Total Monthly Earning Then Admin Needs To Enter Option-4 .

5- If Admin Select Option-5 Then Admin Successfully Logout The Application And Thread Is Going To Stop .


######3- CUSTOMER MENU :

If User Login As Customer Then New Thread Is Created And Customer Menu Will Display .

		|------------------------------| CUSTOMER MENU |----------------------------------|

		1- View Menu   2- Order Item   3- View Final Bill Generated   4- View Profile   5- Log-Out

1- Customer Can View The Food Menu By Selecting Option-1 .

2- Customer Can Order Food Item By Selecting Option-2 .

	|---------------------------| ORDER FOODS FROM MENU |-------------------------------|

	1- Add Dish Into Cart 	 2- Remove Dish From The Cart 	 3- Placed The Order 	 4- Go Back To Customer Menu 

 Here 4 Options Are Given To Customer For Ordering Food From Menu :

- Customer Can Add The Food Item Into Cart By Selecting Option-1 . For That Customer Needs To Enter Food-Id Which Customer Wants To Add Along With No. Of Plates . First It Checks For Food-Id If Matches Then It Checks For No. Of Quantity Which Order By Customer Is Available Or Not If Available Then That Particular Food Item Is Added In The Cart . If Any One Of Them Condition Fails Then It Throws An Exception . 

- If Customer Want To Remove A Particular Food-Item From The Cart Then Customer Needs To Enter Food-Id Which Customer Wants To Remove . If Food-Item Is Exist In The Cart Then It Will Successfully Removed .

- Finally The Food-Items Which Present In The Cart , Customer Wants To Placed That Order Then Customer Needs To Select Option-3 Which Ask For Otp And After Entering Proper Otp , The Food-Item Is Placed Successfully . 

3- Customer Can  View There Final Bill Generated By Selection Option-3 Along With Food Item Which Order By Them .

4- Customer Can View Their Profile By Selectiong Option-4 which Ask For Otp And After Entering Proper Otp , Customer Profile Will Display .

5- At Last By Selection Option-5 Customer Logout The Application Successfully . And The Thread Is Going To Stop .


## Database Query : 

	--> Create Database :
	Create database Miniproject_01 ;

	--> Use Database :
	Use Miniproject_01 ;

	--> Admin Table :
	Create table Admin (Name varchar (30) , Password varchar (20) , Email varchar (30) , PhoneNo varchar (15) , Type varchar (10) , AdminId int , DateOfJoining varchar (15));

	--> Customer Table :
	Create table Customer (Name varchar (30) , Password varchar (20) , Email varchar (30) , PhoneNo varchar (15) , Type varchar (10) , Address varchar (100));

	--> FoodMenu Table :
	Create table FoodMenu (FoodId int , FoodName varchar (30) , FoodPrice decimal (6,2) , NoOfPlates int);

	--> OrderList Table :
	Create table OrderList (CustomerPhoneNo varchar (15) , FoodId int , date date , Price decimal(6,2));

	--> Cart Table ...
	Create table Cart (CustomerPhoneNo varchar (15) , FoodId int , date date , Price decimal(6,2));
			
## Concepts Used :

- Basic Java
- Oops 
- String Handling
- Exception Handling
- Collections
- Regex
- Multi-threading
- JDBC
- Mysql Queries

## Key Points :

- Multiple Admin Can Register And Log-in .
- Multiple Customer Can Register And Log-in .
- j-Unit Testing Is Done For Project .
- Proper Exceptions Handler And Logging Messege Is given .















