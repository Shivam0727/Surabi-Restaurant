package com.project.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.exception.CustomException;
import com.project.pojo.Order;
import com.project.service.AdminService;

@RestController
public class AdminController {

	@Autowired
	AdminService adminService ;

	// Controller for get all todays order done by customer ...
	@GetMapping("/getAllTodaysOrder/{date}")
	public List<Order> getAllTodaysOrder(@RequestParam("date") 
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date date)
	{
		List<Order> order = adminService.getAllTodaysOrder(date);
		if(order.isEmpty()!=true)
		{
			return order ;
		}
		throw new CustomException("Sorry !!! No Order Placed By Today ...");
	}

	// Controller for get all  order done by specific customer ...
	@GetMapping("/getAllOrdersBySpecificUser/{phoneNo}")
	public List<Order> GetAllOrdersBySpecificUser(@PathVariable long phoneNo)
	{
		List<Order> order = adminService.GetAllOrdersBySpecificUser(phoneNo);
		if(order.isEmpty()!=true)
		{
			return order ;
		}
		throw new CustomException("Sorry !!! No Order Placed By Customer Whose Phone Number :: "+phoneNo+" ...");
	}

	// Controller for get total monthly sales ...
	@GetMapping("/getMonthlySales/{month}")
	public String GetMonthlySales(@PathVariable int month)
	{
		Optional<Order> order = adminService.GetMonthlySales(month);
		if(order.isPresent())
		{
			return "Monthly Sales :: "+order.get()+" Rs Only /-";
		}
		return "Monthly Sales :: Zero !!!";
	}

	// Controller for display jsp page ...
	@GetMapping("/user")
	public ModelAndView manageUser()
	{
		return new ModelAndView("user");
	}

	// Controller for display jsp page ...
	@GetMapping("/food")
	public ModelAndView manageFood()
	{
		return new ModelAndView("food");
	}

	// Controller for display jsp page ...
	@GetMapping("/welcomeAdmin")
	public ModelAndView welcomeAdmin()
	{
		return new ModelAndView("welcomeAdmin");
	}

}
