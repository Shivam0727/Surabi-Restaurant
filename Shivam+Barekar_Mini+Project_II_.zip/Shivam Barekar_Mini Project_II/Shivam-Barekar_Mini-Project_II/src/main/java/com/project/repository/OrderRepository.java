package com.project.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.project.pojo.Order;
@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	// Custom Query :
	List<Order> findAllOrderByDate(Date date);
	List<Order> findAllOrderByCustomerPhoneNo(long phoneNo);

	// Custom Query using QUERY Annotation :
	@Query("select Sum(price) as Earning From Order WHERE MONTH(date)=?1")
	Optional<Order> getOrderByDate(int month);

	@Query("select Sum(price) as Bill From Order WHERE customerPhoneNo=?1")
	Optional<Order> getFinalBill(long phoneNo);

}
