package com.project.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.project.pojo.Customer;
import com.project.service.CrudUserService;

@Controller
public class UserController {

	@Autowired
	Customer customer ;

	@Autowired
	CrudUserService crudUserService ;

	@Autowired
	Customer updatedata ;

	@Autowired
	public static Customer customerdetails ;

	public static ArrayList<Customer> displayUser ;

	// Controller for display jsp pages ...
	@GetMapping("/AddUser")
	public ModelAndView addUser()
	{
		return new ModelAndView("AddUser");
	}

	// Controller for display jsp pages ...
	@GetMapping("/DeleteUser")
	public ModelAndView deleteUser()
	{
		return new ModelAndView("DeleteUser");
	}

	// Controller for display jsp pages ...
	@GetMapping("/UpdateUser")
	public ModelAndView updateUser()
	{
		return new ModelAndView("UpdateUser");
	}

	// Controller for display jsp pages ...
	@GetMapping("/DisplayUser")
	public ModelAndView displayUser()
	{
		displayUser = crudUserService.displayAllUsers();
		return new ModelAndView("DisplayUser");
	}

	// Controller for display jsp pages ...
	@GetMapping("/SearchUser")
	public ModelAndView searchUser()
	{
		return new ModelAndView("SearchUser");
	}	

	// Controller for adding user details into H2 base ...
	@PostMapping("/UserAddedSuccessfully")
	public ModelAndView addUserInH2(@RequestParam String user_name , @RequestParam String password , @RequestParam String user_email , @RequestParam String user_gender , @RequestParam long user_phone )
	{
		customer.setName(user_name);
		customer.setPassword(password);
		customer.setEmail(user_email);
		customer.setGender(user_gender);
		customer.setPhoneNo(user_phone);
		customer.setType("Customer");
		crudUserService.addUserDetails(customer);
		return new ModelAndView("UserAddedSuccessfully");
	}

	// Controller for removing user details from H2 base ...
	@PostMapping("/removeUser")
	public ModelAndView removeUserFromH2(@RequestParam long user_phone)
	{
		int result =  crudUserService.removeUser(user_phone);
		if(result==1)
		{
			return new ModelAndView("removeUser");
		}
		else
		{
			return new ModelAndView("userNotFound");
		}
	}

	// Controller for updating user details from H2 base ...
	@PostMapping("/updateUserChecking")
	public ModelAndView updateUserFromH2(@RequestParam String user_name ,@RequestParam String password , @RequestParam String user_email , @RequestParam String user_gender , @RequestParam long user_phone )
	{
		int check = crudUserService.isPresent(user_phone);
		if(check==1)
		{
			updatedata.setName(user_name);
			updatedata.setPassword(password);
			updatedata.setEmail(user_email);
			updatedata.setGender(user_gender);
			updatedata.setPhoneNo(user_phone);
			updatedata.setType("Customer");
			crudUserService.updateUserByPhone(updatedata);
			return new ModelAndView("UpdatedUserSuccessfully");			
		}		
		else
		{
			return new ModelAndView("userNotFound");
		}
	}

	// Controller for searching user details from H2 base ...
	@PostMapping("/searchUserDetails")
	public ModelAndView searchUserFromH2(@RequestParam long user_phone)
	{
		int check = crudUserService.isPresent(user_phone);
		if(check==1)
		{
			customerdetails =crudUserService.getUserDetails(user_phone);
			return new ModelAndView("userDetails");
		}
		else
		{
			return new ModelAndView("userNotFound");
		}
	}
}

