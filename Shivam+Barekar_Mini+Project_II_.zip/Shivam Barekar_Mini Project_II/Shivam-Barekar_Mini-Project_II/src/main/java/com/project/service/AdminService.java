package com.project.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.pojo.Admin;
import com.project.pojo.Order;
import com.project.repository.AdminRepository;
import com.project.repository.OrderRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository ;

	@Autowired
	OrderRepository orderRepository ;

	// Adding the admin details into H2 Base
	public Admin addAdminDetails(Admin admin) {
		return adminRepository.save(admin);		
	}

	// get admin details 
	public Admin getAdminDetails(long user_phone , String user_password) {
		Optional<Admin> optional = adminRepository.findById(user_phone);
		try
		{
			return optional.get();
		}
		catch(Exception e)
		{
			return null;			
		}
	}

	// get all todays order
	public List<Order> getAllTodaysOrder(Date date)
	{
		return orderRepository.findAllOrderByDate(date);
	}

	// Get all orders done by specific user
	public List<Order> GetAllOrdersBySpecificUser(long phoneNo)
	{
		List<Order> result = orderRepository.findAllOrderByCustomerPhoneNo(phoneNo);
		if(result.isEmpty()!=true)
		{
			return result ;
		}
		else
		{
			return null ;
		}
	}

	// Get monthly sales
	public Optional<Order> GetMonthlySales(int month)
	{
		return orderRepository.getOrderByDate(month);
	}

}
