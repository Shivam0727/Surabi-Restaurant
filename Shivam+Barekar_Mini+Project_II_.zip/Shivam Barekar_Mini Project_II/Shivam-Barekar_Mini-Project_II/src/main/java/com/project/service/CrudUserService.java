package com.project.service;

import java.util.ArrayList;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.pojo.Customer;
import com.project.repository.CustomerRepository;

@Service
public class CrudUserService {

	@Autowired
	CustomerRepository customerRepository ;

	// Add user details into H2 Base
	public Customer addUserDetails(Customer customer)
	{
		return customerRepository.save(customer);
	}

	// Remove user details from the H2 Base
	public int removeUser(long phone)
	{
		Optional<Customer> optional = customerRepository.findById(phone);
		try
		{
			Customer customer = optional.get();
			customerRepository.delete(customer);
			return 1 ;
		}
		catch(Exception e)
		{
			return 0 ;
		}

	}

	// Update user details from the H2 base using phone number
	public void updateUserByPhone(Customer updatedUser)
	{
		customerRepository.save(updatedUser);
	}

	// Checking whether user exist or not
	public int isPresent(long phone)
	{
		Optional<Customer> optional = customerRepository.findById(phone);
		if(optional.isPresent()==true)
		{
			return 1 ;
		}
		else
		{
			return 0 ;
		}
	}

	// Get user details from the H2 base
	public Customer getUserDetails(long phone)
	{
		Optional<Customer> optional = customerRepository.findById(phone);
		return optional.get();

	}

	// Display all the users
	public ArrayList<Customer> displayAllUsers() {

		return (ArrayList<Customer>) customerRepository.findAll();
	}
}
