package com.project.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.project.pojo.FoodMenu;
import com.project.service.FoodItemService;

@RestController
public class FoodItemController {

	@Autowired
	FoodItemService foodItemService ;

	@Autowired
	FoodMenu foodMenu ;

	@Autowired
	FoodMenu updatedata ;

	@Autowired
	public static FoodMenu fooddetails ;

	public static ArrayList<FoodMenu> displayFood ;

	// Controller for display jsp pages ...
	@GetMapping("/AddFood")
	public ModelAndView addFood()
	{
		return new ModelAndView("AddFood");
	}

	// Controller for display jsp pages ...
	@GetMapping("/DeleteFood")
	public ModelAndView deleteFood()
	{
		return new ModelAndView("DeleteFood");
	}

	// Controller for display jsp pages ...
	@GetMapping("/UpdateFood")
	public ModelAndView updateFood()
	{
		return new ModelAndView("UpdateFood");
	}

	// Controller for display jsp pages ...
	@GetMapping("/DisplayFood")
	public ModelAndView displayFood()
	{
		displayFood = foodItemService.displayAllFoods();
		if(displayFood.isEmpty()!=true)
		{
			return new ModelAndView("DisplayFood");				
		}
		return new ModelAndView("foodNotFound") ;
	}

	// Controller for display jsp pages ...
	@GetMapping("/SearchFood")
	public ModelAndView searchFood()
	{
		return new ModelAndView("SearchFood");
	}	

	// Controller for adding food items into H2 base ...
	@PostMapping("/FoodAddedSuccessfully")
	public ModelAndView addFoodInH2(@RequestParam int foodId , @RequestParam String foodName , @RequestParam float price , @RequestParam int noOfPlatesAvailable )
	{
		foodMenu.setFoodId(foodId);
		foodMenu.setFoodName(foodName);
		foodMenu.setPrice(price);
		foodMenu.setNoOfPlatesAvailable(noOfPlatesAvailable);
		foodItemService.addFoodDetails(foodMenu);
		return new ModelAndView("FoodAddedSuccessfully");
	}

	// Controller for deleting food items from H2 base ...
	@PostMapping("/removeFood")
	public ModelAndView removeFoodFromH2(@RequestParam int foodId)
	{
		int result =  foodItemService.removeFood(foodId);
		if(result==1)
		{
			return new ModelAndView("removeFood");
		}
		else
		{
			return new ModelAndView("foodNotFound");
		}
	}

	// Controller for update food items which is present in H2 base ...
	@PostMapping("/updateFoodChecking")
	public ModelAndView updateFoodFromH2(@RequestParam int foodId , @RequestParam String foodName , @RequestParam float price , @RequestParam int noOfPlatesAvailable )
	{
		int check = foodItemService.isPresent(foodId);
		if(check==1)
		{
			updatedata.setFoodId(foodId);
			updatedata.setFoodName(foodName);
			updatedata.setPrice(price);
			updatedata.setNoOfPlatesAvailable(noOfPlatesAvailable);
			foodItemService.updateFoodById(updatedata);
			return new ModelAndView("UpdatedFoodSuccessfully");			
		}		
		else
		{
			return new ModelAndView("foodNotFound");
		}
	}

	// Controller for search food items which is present in H2 base ...
	@PostMapping("/searchFoodDetails")
	public ModelAndView searchFoodFromH2(@RequestParam int foodId)
	{
		int check = foodItemService.isPresent(foodId);
		if(check==1)
		{
			fooddetails =foodItemService.getFoodDetails(foodId);
			return new ModelAndView("foodDetails");
		}
		else
		{
			return new ModelAndView("foodNotFound");
		}
	}
}
