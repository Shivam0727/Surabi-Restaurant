package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.pojo.FoodMenu;

public interface FoodItemRepository extends JpaRepository<FoodMenu, Integer> {

}
