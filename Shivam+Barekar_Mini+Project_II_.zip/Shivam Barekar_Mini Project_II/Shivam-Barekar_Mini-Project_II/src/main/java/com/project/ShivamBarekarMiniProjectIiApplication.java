package com.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.pojo.Customer;
import com.project.pojo.FoodMenu;
import com.project.repository.CustomerRepository;
import com.project.repository.FoodItemRepository;

@SpringBootApplication
public class ShivamBarekarMiniProjectIiApplication  implements CommandLineRunner {

	@Autowired
	FoodItemRepository foodItemRepository ;
	@Autowired
	CustomerRepository customerRepository ;
	
	public static void main(String[] args) {
		SpringApplication.run(ShivamBarekarMiniProjectIiApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Added Food Item In The Food Menu Table ...
		List<FoodMenu> dishes = new ArrayList<FoodMenu>();
		dishes.add(new FoodMenu(1,"Dal Fry",120.0f,20));
		dishes.add(new FoodMenu(2,"Dal Makhani",150.0f,20));
		dishes.add(new FoodMenu(3,"Dum Aloo",160.0f,20));
		dishes.add(new FoodMenu(4,"Mix Veg Curry",180.0f,20));
		dishes.add(new FoodMenu(5,"Masala Paneer",220.0f,20));
		dishes.add(new FoodMenu(6,"Palak Panner",220.0f,20));
		dishes.add(new FoodMenu(7,"Mutter Paneer",200.0f,20));
		dishes.add(new FoodMenu(8,"Paneer Makhanni",200.0f,20));
		dishes.add(new FoodMenu(9,"Paneer Bhurji",180.0f,20));
		dishes.add(new FoodMenu(10,"Paneer Kofta",230.0f,20));
		dishes.add(new FoodMenu(11,"Egg Curry",120.0f,20));
		dishes.add(new FoodMenu(12,"Butter Chicken",280.0f,20));
		dishes.add(new FoodMenu(13,"Chicken Curry",300.0f,20));
		dishes.add(new FoodMenu(14,"Chicken Tandoori",250.0f,20));
		dishes.add(new FoodMenu(15,"Tandori Roti",20.0f,20));
		dishes.add(new FoodMenu(16,"Butter Tandori Roti",25.0f,20));
		dishes.add(new FoodMenu(17,"Tawa Roti",15.0f,20));
		dishes.add(new FoodMenu(18,"Rumali Roti",25.0f,20));
		dishes.add(new FoodMenu(19,"Lacha Paratha",30.0f,20));
		dishes.add(new FoodMenu(20,"Aloo Paratha",40.0f,20));
		dishes.add(new FoodMenu(21,"Onion Paratha",35.0f,20));
		dishes.add(new FoodMenu(22,"Paneer Paratha",55.0f,20));
		dishes.add(new FoodMenu(23,"Boiled Rice",100.0f,20));
		dishes.add(new FoodMenu(24,"Zeera Rice",125.0f,20));
		dishes.add(new FoodMenu(25,"Paneer Fried Rice",165.0f,20));
		dishes.add(new FoodMenu(26,"Egg Biryani",180.0f,20));
		dishes.add(new FoodMenu(27,"Chilli Chicken",180.0f,20));
		dishes.add(new FoodMenu(28,"Paneer Thali",280.0f,20));
		dishes.add(new FoodMenu(29,"Punjabi Special Thali",350.0f,20));
		dishes.add(new FoodMenu(30,"Maharastrian Special Thali",350.0f,20));
		// Save The FoodItem Into FoodMenu Table ...
		foodItemRepository.saveAll(dishes);
		
		// Added Some Dummy Customer In The Customer Table ...
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(new Customer("Pratik Thakre", "Pratik@123", "pratikthakre12@gmail.com", "Male", 9523829941L, "Customer"));
		customers.add(new Customer("Dipali Kutmure", "Dipali@123", "drkutmure@gmail.com", "Female", 6741871542L, "Customer"));
		customers.add(new Customer("Namrata Patil", "Namrata@123", "nammepatil@gmail.com", "Female", 7786593303L, "Customer"));
		customers.add(new Customer("Kunal Singh", "Kunal@123", "kunalsingh@gmail.com", "Male", 9266829948L, "Customer"));
		customers.add(new Customer("Puja Kanjalwar", "KjPuja@123", "pujakanjalwar08@gmail.com", "Female", 8323819953L, "Customer"));
		// Save The Customer Details In The Customer Table ...
		customerRepository.saveAll(customers);
	
	}
}
