package com.project.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

//Pojo for FoodMenu
@Component
@Entity
@Table(name="Food_Details")
public class FoodMenu {
	@Id
	private int foodId ;
	private String foodName ;
	private float price ;
	private int noOfPlatesAvailable ;
	
	// Getter-Setter
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getNoOfPlatesAvailable() {
		return noOfPlatesAvailable;
	}
	public void setNoOfPlatesAvailable(int noOfPlatesAvailable) {
		this.noOfPlatesAvailable = noOfPlatesAvailable;
	}
	
	// Parameterized Constructor
	public FoodMenu(int foodId, String foodName, float price, int noOfPlatesAvailable) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.price = price;
		this.noOfPlatesAvailable = noOfPlatesAvailable;
	}
	
	// Default Constructor
	public FoodMenu() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// To-String Method
	@Override
	public String toString() {
		return "FoodMenu [foodId=" + foodId + ", foodName=" + foodName + ", price=" + price + ", noOfPlatesAvailable="
				+ noOfPlatesAvailable + "]";
	}
}
