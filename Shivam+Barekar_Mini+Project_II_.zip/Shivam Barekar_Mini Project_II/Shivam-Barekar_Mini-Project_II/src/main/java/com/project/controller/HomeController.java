package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.project.pojo.Admin;
import com.project.pojo.Customer;
import com.project.service.AdminService;
import com.project.service.CustomerService;

@RestController
public class HomeController {

	@Autowired
	Admin admin ;
	@Autowired
	Customer customer ;

	@Autowired
	AdminService adminService ;

	@Autowired
	CustomerService customerService ;

	static long phoneNo ;
	public static Customer profile ;

	// Controller for display jsp pages ...
	@GetMapping("/home")
	public ModelAndView home()
	{
		return new ModelAndView("home");
	}

	// Controller for display jsp pages ...
	@GetMapping("/signin")
	public ModelAndView login()
	{
		return new ModelAndView("login");
	}

	// Controller for display jsp pages ...
	@GetMapping("/signup")
	public ModelAndView register()
	{
		return new ModelAndView("register");
	}

	// Controller for adding user/admin details into H2 base ...
	@PostMapping("/registerInfo")
	public ModelAndView addAdmin(@RequestParam String user_name , @RequestParam String user_password , @RequestParam String user_email , @RequestParam String user_gender , @RequestParam long user_phone , @RequestParam String type )
	{
		if(type.equals("Admin"))
		{
			admin.setName(user_name);
			admin.setPassword(user_password);
			admin.setEmail(user_email);
			admin.setGender(user_gender);
			admin.setPhoneNo(user_phone);
			admin.setType(type);
			adminService.addAdminDetails(admin);	
		}
		else
		{
			customer.setName(user_name);
			customer.setPassword(user_password);
			customer.setEmail(user_email);
			customer.setGender(user_gender);
			customer.setPhoneNo(user_phone);
			customer.setType(type);
			customerService.addCustomerDetails(customer);	
		}
		return new ModelAndView("registerInfo");

	}
	
	// Controller for login by admin/user ...
	@PostMapping("/loginInfo")
	public ModelAndView checkAdmin(@RequestParam long user_phone , @RequestParam String user_password , @RequestParam String type)
	{
		String password = null ;
		if(type.equals("Admin"))
		{
			Admin result = adminService.getAdminDetails(user_phone , user_password);
			if(result!=null)
			{
				password = result.getPassword();				
				if(password.equals(user_password))
				{
					phoneNo = user_phone ;
					return new ModelAndView("welcomeAdmin");			
				}
				else
				{
					return new ModelAndView("notexist");
				}
			}
			else
			{
				return new ModelAndView("notexist");
			}
		}
		else
		{
			Customer result = customerService.getCustomerDetails(user_phone , user_password);
			if(result!=null)
			{
				password = result.getPassword();				
				if(password.equals(user_password))
				{
					profile=result ;
					phoneNo = user_phone ;
					return new ModelAndView("welcomeCustomer");			
				}
				else
				{
					return new ModelAndView("notexist");
				}
			}
			else
			{
				return new ModelAndView("notexist");
			}
		}
	}
	
	// Controller for display jsp pages ...
	@GetMapping("/logout")
	public ModelAndView Logout()
	{
		return new ModelAndView("logout");
	}

}
