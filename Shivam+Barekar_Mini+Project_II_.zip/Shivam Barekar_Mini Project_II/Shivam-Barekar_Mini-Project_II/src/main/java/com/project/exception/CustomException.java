package com.project.exception;

@SuppressWarnings("serial")
public class CustomException extends RuntimeException {

	public CustomException(String msg) {
		// Msg for storing custom exceptions ...
		super(msg);
	}
	
}
