package com.project.pojo;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

//Pojo for Cart
@Component
@Entity
@Table(name="Customer_Cart")
public class Cart {
	@Column(name="Customer_Contact")
	private long customerPhoneNo ;
	@Id
	@Column(name="Food_Id")
	private int foodId ;
	@Column(name="Food_Added_Date")
	private Date date ;
	@Column(name="Food_Item_Price")
	private float price ;

	// Getter-Setter
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public long getCustomerPhoneNo() {
		return customerPhoneNo;
	}
	public void setCustomerPhoneNo(long customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	// Default Constructor
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Parameterized Constructor
	public Cart(long customerPhoneNo, int foodId, Date date, float price) {
		super();
		this.customerPhoneNo = customerPhoneNo;
		this.foodId = foodId;
		this.date = date;
		this.price = price;
	}
	
	// To-String method
	@Override
	public String toString() {
		return "Cart [customerPhoneNo=" + customerPhoneNo + ", foodId=" + foodId + ", date=" + date + ", price="
				+ price + "]";
	}	
}
