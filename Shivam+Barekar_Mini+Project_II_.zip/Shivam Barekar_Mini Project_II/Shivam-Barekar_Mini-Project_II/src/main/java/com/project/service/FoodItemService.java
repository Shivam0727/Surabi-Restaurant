package com.project.service;

import java.util.ArrayList;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.pojo.FoodMenu;
import com.project.repository.FoodItemRepository;

@Service
public class FoodItemService {

	@Autowired
	private FoodItemRepository foodItemRepository ;

	// Service for adding food items into H2 base ...
	public FoodMenu addFoodDetails(FoodMenu foodMenu)
	{
		return foodItemRepository.save(foodMenu);
	}

	// Service for deleting food items from H2 base ...
	public int removeFood(int foodId)
	{
		Optional<FoodMenu> optional = foodItemRepository.findById(foodId);
		try
		{
			FoodMenu foodMenu = optional.get();
			foodItemRepository.delete(foodMenu);
			return 1 ;
		}
		catch(Exception e)
		{
			return 0 ;
		}

	}
	// Service for update food items which is present in H2 base ...
	public void updateFoodById(FoodMenu updatedFood)
	{
		foodItemRepository.save(updatedFood);
	}

	// Checking whether food Details present or not
	public int isPresent(int foodId)
	{
		Optional<FoodMenu> optional = foodItemRepository.findById(foodId);
		if(optional.isPresent()==true)
		{
			return 1 ;
		}
		else
		{
			return 0 ;
		}
	}

	// Service for search food items which is present in H2 base ...
	public FoodMenu getFoodDetails(int foodId)
	{
		Optional<FoodMenu> optional = foodItemRepository.findById(foodId);
		return optional.get();

	}

	// get all food Items details from the H2 base
	public ArrayList<FoodMenu> displayAllFoods() {

		return (ArrayList<FoodMenu>) foodItemRepository.findAll();
	}
}
