package com.project.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.exception.CustomException;
import com.project.pojo.Cart;
import com.project.pojo.FoodMenu;
import com.project.pojo.Order;
import com.project.service.CustomerService;
import com.project.service.FoodItemService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService ;

	@Autowired
	FoodItemService foodItemService ;

	@Autowired
	Cart cart ;

	public static ArrayList<FoodMenu> displayFood ;

	// Controller for get all Food Menu Item which is added by the admin ...
	@GetMapping("/getFoodMenu")
	public List<FoodMenu> getFoodMenu()
	{
		List<FoodMenu> menu = customerService.getFoodMenu();
		if(menu.isEmpty()!=true)
		{
			return menu ;
		}
		throw new CustomException("Sorry !!! No Food Item Added By The Admin ...");
	}

	// Controller for adding food items into food cart depending on foodId ...
	@GetMapping("/addFoodIntoCart/{foodId}/{noOfQuantity}")
	public String getFoodItemById(@PathVariable int foodId , @PathVariable int noOfQuantity)
	{
		FoodMenu foodItem = customerService.getFoodItemById(foodId , noOfQuantity);
		if(foodItem!=null)
		{
			cart.setCustomerPhoneNo(HomeController.phoneNo);
			cart.setFoodId(foodId);
			cart.setPrice(noOfQuantity*foodItem.getPrice());
			long millis=System.currentTimeMillis();  
			Date date = new Date(millis);
			cart.setDate(date);
			customerService.addFoodItemIntoCart(cart);
			return "Congratulations Food Added In The Cart Successfully";

		}
		return "Sorry Unfortunately Food Is Not Added In The Cart !!! Please Try Again ..." ;
	}

	// Controller for placed order which is present in the customer cart  ...
	@GetMapping("/placedOrder")
	public String placedOrder()
	{
		List<Cart> cart = customerService.getAllCartItems();
		if(cart.isEmpty()!=true)
		{
			Order order = new Order();
			for(int i=0 ; i<cart.size() ; i++) {
				order.setCustomerPhoneNo(cart.get(i).getCustomerPhoneNo());
				order.setFoodId(cart.get(i).getFoodId());
				order.setDate(cart.get(i).getDate());
				order.setPrice(cart.get(i).getPrice());
				customerService.addOrderDetails(order);
			}

			customerService.deleteCartItems();
			return "Order Placed Successfully";
		}
		return "Sorry , Your Cart Is Empty !!! Please Add Food Into Cart ...";
	}

	// Controller for get final bill generated for order which is done by customer ...
	@GetMapping("/finalBillGenerated/{customerPhoneNo}")
	String getFinalBill(@PathVariable long customerPhoneNo)
	{
		Optional<Order> price = customerService.getFinalBill(customerPhoneNo);
		if(price.isPresent())
		{
			return "Final Bill Generated :: "+price.get()+" Rs Only /-";			
		}
		return "No Order Placed Till Now ...";
	}

	// Controller for get all the food item which is present in the cart ...
	@GetMapping("/getAllCartItems")
	List<Cart> getAllCartItems()
	{
		List<Cart> cart = customerService.getAllCartItems();
		if(cart.isEmpty()!=true)
		{
			return cart ;
		}
		throw new CustomException("Sorry !!! Your Cart Is Empty ...");
	}

	// Controller for get order history for a specific customer ...
	@GetMapping("/getOrderHistory/{customerPhoneNo}")
	List<Order> getOrderHistory(@PathVariable long customerPhoneNo)
	{
		List<Order> order = customerService.GetAllOrdersBySpecificUser(customerPhoneNo);
		if(order.isEmpty()!=true)
		{
			return order ;
		}
		throw new CustomException("Sorry !!! You Are Not Ordered Any Food Item Till Now ...");
	}

	// Controller for display jsp pages ...
	@GetMapping("/displayFoodMenu")
	public ModelAndView manageFood()
	{
		displayFood = foodItemService.displayAllFoods();
		if(displayFood.isEmpty()!=true)
		{
			return new ModelAndView("displayFoodMenu");
		}
		return new ModelAndView("menuNotFound");
	}

	// Controller for display jsp pages ...
	@GetMapping("/welcomeCustomer")
	public ModelAndView welcomeCustomer()
	{
		return new ModelAndView("welcomeCustomer");
	}

	// Controller for display jsp pages ...
	@GetMapping("/viewProfile")
	public ModelAndView viewProfile()
	{
		return new ModelAndView("viewProfile");
	}
}


