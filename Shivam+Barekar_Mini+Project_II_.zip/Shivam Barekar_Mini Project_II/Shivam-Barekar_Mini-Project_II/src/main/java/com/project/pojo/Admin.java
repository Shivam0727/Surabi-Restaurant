package com.project.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

// Pojo for Admin
@Component
@Entity
@Table(name="Admin_Details")
public class Admin {

	@Column(name="Admin_Name")
	private String name ;
	@Column(name="Password")
	private String password ;
	@Column(name="Admin_Email")
	private String email ;
	@Column(name="Admin_Gender")
	private String gender ;
	@Id
	@Column(name="Admin_PhoneNo")
	private long phoneNo ;
	@Column(name="User_Type")
	private String type ;

	// Getter-Setter
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	// Parameterized Constructor
	public Admin(String name, String password, String email, String gender, long phoneNo, String type) {
		super();
		this.name = name;
		this.password = password;
		this.email = email;
		this.gender = gender;
		this.phoneNo = phoneNo;
		this.type = type;
	}

	// Default Constructor
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	// To-String method
	@Override
	public String toString() {
		return "Admin [name=" + name + ", password=" + password + ", email=" + email + ", gender=" + gender
				+ ", phoneNo=" + phoneNo + ", type=" + type + "]";
	}		
}
