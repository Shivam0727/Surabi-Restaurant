# Mini Project II

This Application is an extension of Mini Project-I (Core Java)

# Problem Statement :

Surabi is a chain of restaurants Now wants to come online.

## Use Stories

##### Users :
1. As a user I should be able to log in and log out and register in the application.
2. As a user I should be able to see all the items available along with the price.
3. As a user I should be able to select the item I want to order.
4. As a user I should be able to order n number of plates per item,
5. As a user I should be able to order more than one item.
6. As a user I should be able to see my final bill on the screen.
7. As a user I should be able to my cart and my order History

##### Admin :
1. As an admin I should be able to login and logout in the application
2. As an admin I should be able to perform CRUD on Users
3. As an admin I should be able to see all the bills getting generated today.
4. As an admin I should be able to see the total sale from this month.
5. As an admin I should be able to see all the orders done by a specific user.
6. As an admin I should be able to perform CRUD on menu and menu items.

## Requirements : 

- IDE like Eclipse or Spring Tool Suite for developement of code .
- JDK version 8 or more .
- Soap-UI for managing the rest-APIs .
- MySQL database to store the data .
- Maven repository to adding the dependancy in the project .
  
##### Note : 

- Instead of MySQL we are using H2 Base which is in-memory storage which helps to store the data using localhost server .
- Instead of Soap-UI We are using Swagger-UI to implements or access the rest-APIs .

## Process : 

- Run the project as java application .
- After running the project just go to the any web browser to see the output . You can go with chrome or microsoft edge . 
- After opening the web browser go to the search bar and paste the url which is given below :

	URL : localhost:8080/home

- After entering the url your browser loads a home page where you can see login and register option .
- Now whether you are admin or customer first go for registration process . By click on the 'Register' the registration page is opening whether you need to enter the details . If you enter type as Admin then user will consider as Admin and if you select type as Customer then user will consider as Customer .
- After entering the details you need to click on register button after that you can see that registration successfully page . 
- After that you need to login the application by clicking on 'Login' button which is present in home page . You need to enter the proper login credentials to login in the application .
- Login credentials will be check and if present then it will load a welcome page according to user and if login credentials doesnot exist then if will load a user not found page .
- Now consider if you login as Admin then a welcomeAdmin page opens where you can see 3 options :

		1- Manage Food Items
		2- Manage User Details
		3- Logout
		
- If as a admin you click on the 3rd option then you are successfully logout from the system . 
- If admin click on the manage food items then a page open where you can see 6 options . You can add the food items , you can delete the food items , you can update the food items , you can display the food items , you can search the food items and at last you can go back to welcomeAdmin page .		
- If admin click on the manage user details then a page open where you can see 6 options . You can add the user details , you can delete the user details , you can update the user details , you can display the user details , you can search the user details and at last you can go back to welcomeAdmin page .		
- Now 2 more buttons you can see on the welcomeAdmin page i.e; Go to swagger-ui and Go to H2-console .
- H2 console is basically a in-memory storing database where you can see all the data which you enter or you can manipulate .
- In swagger-ui you can see controllers . As you are login as admin so you need to open admin controller . Where you can see 3 important API's which you need to access which are listed below :

	GET /getAllOrdersBySpecificUser/{phoneNo} 
	GET /getAllTodaysOrder/{date}
	GET /getMonthlySales/{month}
	
- Initially this APIs is not helpful until the customer login and perform some task .	So for that first admin needs to logout .
- Now lets say customer login with their own login credentials and after login successful you can see that a welcomeCustomer page comes up with 3 options which are mentioned as shown below : 
	
	1- Display Food Items 
	2- View Profile
	3- Logout
	
- If as a customer you click on the 3rd option then you are successfully logout from the system . 
- Now if i click on the view profile button then it will display his/her own details .
- If i clicked on display food items then it will display all the food menu which is added by the admin . 
- Now 2 more buttons you can see on the welcomeCustomer page i.e; Go to swagger-ui and Go to H2-console .
- H2 console is basically a in-memory storing database where you can see all the data which you enter or you can manipulate .
- In swagger-ui you can see controllers . As you are login as customer so you need to open customer controller . Where you can see 7 important API's which you need to access which are listed below :

	GET /addFoodIntoCart/{foodId}/{noOfQuantity}
	GET /displayFoodMenu
	GET /finalBillGenerated/{customerPhoneNo}
	GET /getAllCartItems
	GET /getFoodMenu
	GET /getOrderHistory/{customerPhoneNo}
	GET /placedOrder
	
- Now as a customer you can check the cart first is it empty or not by click on API getAllCartItems . you can see it as empty .	
- Now first you need to view food menu by clicking on API displayFoodMenu . It will fetch all the food items . According to your choice select the food items  with the number of quantity you want to added in the cart . For this you can use an API addFoodIntoCart .  
- After adding food items into cart you can go with API getAllCartItems to view all the food items which is added by you . 
- After that you can places the order by clicking on the API placeOrder . 
- If you want to view your final bill generated then you can click on the API finalBillGenerated where you need to enter your own phonenumber .
- If you want to get your order history then you can go for API getOrderHistory . 
- Now you can see all the functionality works properly so now you can logout .
- Now again as i mentioned you need to check 3 APIs as a Admin so you need to login as a Admin with admin credentials .
- After login just go to Swagger-ui and check the APIs inside admin controller .
- Now as a admin if you want to check the monthly sales then you need to click on the API getMonthlySales . 
- If you want to check the total todays earning then you need to go for API getAllTodaysOrder .
- If you want to check a specific user order history then you need to go for API getAllOrdersBySpecificUser where you need to pass the contact number of that perticular user .
- After performing all the functionality successfully you can logout the system .
- Atlast we can conclude that all the functionality works properly and we can implement the project successfully . 

## Future Scope : 

1- We can replace all the JSP pages with front-end technology for better experience .

2- We can give the authentication and authorization to a specific user by using concept called as Spring Security .

3- We can perform the testing of project using Mokito .

4- We can deployee the whole project on gitlab or digital ocean .

-----

















































